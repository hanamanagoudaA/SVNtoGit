Eclipse by default runs validation on all jsp and xml files and reports any errors. At least when initially importing the project, I suggest suspending all validators because it can take quite a while.
<P>
<B>Select Window->Preferences:</B><br/>
<P>
[[images/eclipse/window_preferences.jpg|alt=Select Window->Preferences]]
<P>
<B>Under Validation you will see something like this, click Suspend All Validators and click Apply and Close:</B><br/>
[[images/eclipse/maven_suspend_all_validators.jpg|alt=Click Suspend All Validators and click Apply and Close]]
<P>
