Eclipse itself runs using a JRE >= Java8.  Because IVR runs using a Java7 JRE, we need to configure eclipse to use the Java7 JRE when running.
<P>
<B>Select Window->Preferences:</B><br/>
<P>
[[images/eclipse/window_preferences.jpg|alt=Select Window->Preferences]]
<P>
<B>Under Java->Installed JRE's you will see something like this, click Add:</B><br/>
[[images/eclipse/installed_jres_default.jpg|alt=Click Add]]
<P>
<B>Select Standard VM and click Next:</B><br/>
[[images/eclipse/jre_select_type.jpg|alt=Select Standard VM and click Next]]
<P>
<B>Select the directory where your JDK JRE is located and click Finish:</B><br/>
[[images/eclipse/jre_select_directory.jpg|alt=Select the directory where your JDK JRE is located and click Finish]]
<P>
<B>Select the checkbox for the Java7 JRE you just added and click Apply and Close:</B><br/>
[[images/eclipse/jre_select_checkbox.jpg|alt=Select the checkbox for the Java7 JRE you just added and click Apply and Close]]

