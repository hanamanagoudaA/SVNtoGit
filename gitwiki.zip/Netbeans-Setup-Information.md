For starting with a clean workspace, follow these steps to configure netbeans and open the mst-ivr maven project:
1. [[Netbeans Maven Configuration|Netbeans Maven Configuration]]<br/><br/>
2. [[Netbeans Open Maven Project|Netbeans Open Maven Project]]<br/><br/>
