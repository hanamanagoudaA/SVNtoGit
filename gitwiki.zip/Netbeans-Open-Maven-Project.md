To open the MST-IVR maven project in NetBeans:
<P>
Netbeans comes out of the box with maven support. There is no need to use an Import function, you just Open the project directory and NetBeans seems smart enough to detect the pom.xml and act accordingly.
<P>
<B>Select File->Open Project:</B><br/>
<P>
[[images/netbeans/file_open_project.jpg|alt=Select File->Open Project]]
<P>
<B>Browse to your mst-ivr git directory and select Open Project:</B><br/>
<P>
[[images/netbeans/open_project_mst_ivr.jpg|alt=Browse to your mst-ivr git directory and select Open Project]]
<P>
<B>After a short time it opens the project, but takes a while doing some kind of artifactory indexing, here is a screenshot:</B><br/>
<P>
[[images/netbeans/open_project_started_messing_with_artifactory_index.jpg|alt=Screenshot during project opening]]
<B>You can select Run->Clean and Build Project and it runs maven in a Window for you:</B><br/>
<P>
[[images/netbeans/project_open_and_compiled.jpg|alt=Screenshot after project built]]

