For starting with a clean workspace, follow these steps to configure eclipse and import the mst-ivr maven project:
1. [[Eclipse JRE Configuration|Eclipse JRE Configuration]]<br/><br/>
2. [[Eclipse Maven Settings Configuration|Eclipse Maven Settings Configuration]]<br/><br/>
3. [[Eclipse Tomcat Settings Configuration|Eclipse Tomcat Settings Configuration]]<br/><br/>
4. [[Eclipse Suspend All Validators|Eclipse Suspend All Validators]]<br/><br/>
5. [[Eclipse Import Maven Project|Eclipse Import Maven Project]]<br/><br/>


