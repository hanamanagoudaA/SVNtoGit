[[Git basics and getting started|Git basics and getting started]]<br/><br/>
[[gitflow branching strategy|gitflow branching strategy]]<br/><br/>
[[git bash cheatsheet|git bash cheatsheet]]<br/><br/>
[[git screencasts|git screencasts]]<br/><br/>
[[git FAQ|git FAQ]]<br/><br/>