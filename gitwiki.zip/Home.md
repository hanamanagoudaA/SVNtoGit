Welcome to the mst-ivr wiki!

**VERY IMPORTANT:** After installing git and *before cloning any repositories,* open git bash and run this command. You only have to do this once. If you do not do this, when cloning the repository you will see lots of errors as git will try to modify the end-of-line markers on many files and create a very large mess for you to fix. Here is the command:<br/>
**git config --global core.autocrlf false**

