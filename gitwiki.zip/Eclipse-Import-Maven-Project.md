To import the MST-IVR maven project into eclipse:
<P>
<B>Select File->Import:</B><br/>
<P>
[[images/eclipse/project_import.jpg|alt=Select File->Import]]
<P>
<B>Select Maven->Existing Maven Project:</B><br/>
<P>
[[images/eclipse/project_import_maven.jpg|alt=Select Maven->Existing Maven Project]]
<P>
<B>Select Browse, select your git mst-ivr directory, and click OK:</B><br/>
<P>
[[images/eclipse/maven_import_mst.jpg|alt=Select Browse, select your git mst-ivr directory, and click OK]]
<P>
<B>Click Finish:</B><br/>
<P>
[[images/eclipse/maven_import_finish.jpg|alt=Click Finish]]
<P>
<B>When import is completed, it should look similar to this:</B><br/>
<P>
[[images/eclipse/maven_import_complete.jpg|alt=Click Finish]]
<P>