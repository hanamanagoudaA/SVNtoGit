## Here is a high level overview of gitflow, paste this link to your windows explorer or open with Windows Media Player:<br/>\\\\Rxsnt01\depts\Common\PM Working Documents\Business Verticals\Customer Service\RXHD\RXHD TEAM\Developers\git_docs\gitflow_overview.mp4

## Here is a gitflow tutorial using git bash, paste this link to your windows explorer or open with Windows Media Player:<br/>\\\\Rxsnt01\depts\Common\PM Working Documents\Business Verticals\Customer Service\RXHD\RXHD TEAM\Developers\git_docs\git_flow_demo.mp4

